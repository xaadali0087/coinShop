import React from 'react'

import { createWeb3Modal, defaultWagmiConfig } from '@web3modal/wagmi/react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { WagmiConfig } from 'wagmi'

import SettingsContextProvider from '@/contexts/SettingsContext'
import W3iContextProvider from '@/contexts/W3iContext'
import ConfiguredRoutes from '@/routes'
import { polyfill } from '@/utils/polyfill'
import { initSentry } from '@/utils/sentry'

import { Modals } from './Modals'

import './index.css'

polyfill()
initSentry()

const projectId = import.meta.env.VITE_PROJECT_ID
import { arbitrum,
	avalanche,
	bsc,
	fantom,
	gnosis,
	mainnet,
	optimism,
	polygon,
	bronos,
	goerli,
	arbitrumGoerli,
	arbitrumNova,
	aurora,
	auroraTestnet,
	base,
	baseGoerli,
	boba,
	classic,
	bronosTestnet,
	bxn,
	canto,
	celo,
	crossbell,
	dfk,
gobi,
gnosisChiado,
haqqMainnet,
haqqTestedge2,
harmonyOne,
iotex,
iotexTestnet,
klaytn,
linea,
lineaTestnet,
mantle,
mantleTestnet,
metis,
edgeware,
edgewareTestnet,
eos,
eosTestnet,
ekta,
evmos,
fibo,
filecoin,
filecoinCalibration,
filecoinHyperspace,
flare,
flareTestnet,
fuse,
fuseSparknet,
metisGoerli,
mev,
mevTestnet,
modeTestnet,
moonbaseAlpha,
moonbeam,
moonriver,
neonDevnet,
neonMainnet,
nexilix,
nexi,
oasys,
okc,
optimismGoerli,
polygonMumbai,
polygonZkEvm,
polygonZkEvmTestnet,
pulsechain,
pulsechainV4,
qMainnet,
qTestnet,
rollux,
ronin,
saigon,
scrollSepolia,
scrollTestnet,
sepolia,
shardeumSphinx,
skaleCalypso,
skaleCalypsoTestnet,
skaleChaosTestnet,
skaleCryptoBlades,
skaleCryptoColosseum,
skaleEuropa,
skaleEuropaTestnet,
skaleExorde,
skaleHumanProtocol,
skaleNebula,
skaleNebulaTestnet,
skaleRazor,
skaleTitan,
skaleTitanTestnet,
syscoin,
syscoinTestnet,
songbird,
songbirdTestnet,
taikoTestnetSepolia,
taraxa,
taraxaTestnet,
telos,
telosTestnet,
thunderTestnet,
titan,
titanTestnet,
wanchain,
wanchainTestnet,
xdc,
xdcTestnet,
zetachainAthensTestnet,
zkSync,
zkSyncTestnet,
zora,
zoraTestnet,
foundry,
hardhat,
localhost,

 } from 'wagmi/chains'

const chains = [mainnet,
	polygon,
	avalanche,
	arbitrum,
	bsc,
	optimism,
	gnosis,
	fantom,
	aurora,
    evmos,
    filecoin,
	base,
	celo,
    iotex,
    metis,	
    moonbeam,
    moonriver,
    zora,
    zkSync,
	localhost

	]

const metadata = {
  name: 'DashCoin',
  description: 'Create Account',
  url: 'https://app.web3inbox.com',
  icons: ['https://app.web3inbox.com/connect-icon.png']
}
const wagmiConfig = defaultWagmiConfig({ chains, projectId, metadata })

createWeb3Modal({
  wagmiConfig,
  enableAnalytics: import.meta.env.PROD,
  chains,
  projectId,
  themeMode: 'light',
  themeVariables: {
  '--w3m-z-index': 9999
  }
  
})

// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <WagmiConfig config={wagmiConfig}>
      <SettingsContextProvider>
        <BrowserRouter>
          <W3iContextProvider>
            <ConfiguredRoutes />
            <Modals />
          </W3iContextProvider>
        </BrowserRouter>
      </SettingsContextProvider>
    </WagmiConfig>
  </React.StrictMode>
)
